<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forget Password</title>
    <link rel="stylesheet" href="Styles/loginstyle.css">
</head>
<body>
    <div class="container">
        <form action="send_reset_link.php" method="post">
            <h1>Forget Password</h1>
            <p>Please enter your email address to search for your account.</p>
            <input type="email" name="email" placeholder="Email" required>
            <button type="submit">Send Reset Link</button>
        </form>
    </div>
</body>
</html>
