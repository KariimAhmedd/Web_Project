<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/vissa.css">
    <title>Visa Payment</title>
</head>
<body>
    <header>
        <h1>Visa Payment</h1>
    </header>

    <main>
        <h2>Enter Visa Payment Details</h2>
        <form id="visaForm" action="process_visa_payment.php" method="post">
            <!-- Input fields for Visa payment details -->
            <label for="card_number">Card Number:</label>
            <input type="text" id="card_number" name="card_number" required>

            <label for="expiry_date">Expiry Date:</label>
            <input type="text" id="expiry_date" name="expiry_date" required>

            <label for="cvv">CVV:</label>
            <input type="text" id="cvv" name="cvv" required>

            <button type="submit">Submit Payment</button>
        </form>
        
    </main>

    <footer>
        <p>Contact Us : 17871 | Shift@gmail.com</p>
        <p>Follow us : @Shift_Performances</p>
        <p>© 2024 Car Parts Galore. All rights reserved.</p>   
    </footer>

    <script>
        // Add event listener to form submission
        document.getElementById("visaForm").addEventListener("submit", function(event) {
            // Prevent the form from submitting normally
            event.preventDefault();
            
            // Submit the form data asynchronously using JavaScript
            fetch(this.action, {
                method: this.method,
                body: new FormData(this)
            })
            .then(response => {
                // Check if the payment was successful (You may need to customize this based on your payment processing logic)
                    // Redirect to thank_you.php
                    window.location.href = "thank_you.html";
               
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
