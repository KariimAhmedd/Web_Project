<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/cart.css">
    <title>Shopping Cart</title>
</head>
<body>
    <header>
        <a href="home.php">
            <h1 id="site-name">Shift Store</h1>
        </a>
        <h3 id="under-name">For tuning and modification</h3>
    </header>

    <nav class="top-menu">
        <ul>
            <li class="dropmenu">
                <a href="vehicle.php" class="vehicle">VEHICLE</a>
                <ul class="dropdown-menu vehicle-dropdown">
                    <li><a href="product.php?brand=audi">AUDI</a></li>
                    <li><a href="product.php?brand=bmw">BMW</a></li>
                    <li><a href="product.php?brand=mercedes">MERCSDES</a></li>
                    <li><a href="product.php?brand=vw">VW</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="product.php">PRODUCTS</a>
                <ul class="dropdown-menu product-dropdown">
                    <li><a href="product.php?category=rims">Rims</a></li>
                    <li><a href="product.php?category=exhaust">Exhaust System</a></li>
                    <li><a href="product.php?category=intake">Intake</a></li>
                    <li><a href="product.php?category=suspensions">Suspensions</a></li>
                    <li><a href="product.php?category=software">Software/Tuning</a></li>
                    <li><a href="product.php?category=turbo">Turbo/Superchargers</a></li>
                </ul>
            </li>
            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="support.php">SUPPORT</a></li>
            <li>
                    <div id="welcome-message">
                    <?php
                    // Start session
                    session_start();

                    // Check if the user is logged in
                    if (isset($_SESSION['user_name'])) {
                        // User is logged in, display the welcome message
                        echo '<li>Welcome, ' . htmlspecialchars($_SESSION['user_name']) . '!</li>';
                        // Add logout link here if needed
                    } else {
                        // User is not logged in, display login link
                        echo '<li><a href="login.html" id="login-button"><i class="fa fa-user"></i> LOGIN</a></li>';
                    }
                    ?>
                    </div>
            </li>
            <li>
            <a href="logout.php" id="login-button"><i class="fa fa-user"></i> LOGOUT</a>
            </li>
        </ul>
    </nav>

    <main>
        <h2>Shopping Cart</h2>
        <?php
    // Your PHP code to retrieve items from the database
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "product";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to fetch products from cart
        $cart_query = "SELECT * FROM cart";
        $cart_result = $conn->query($cart_query);
        if ($cart_result->num_rows > 0) {
            // Initialize total sum
            $total_sum = 0;
            ?>
            <div class="cart-section">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($cart_row = $cart_result->fetch_assoc()) {
                            ?>
                            <tr>
                                <td class="product-info">
                                    <div>
                                        <img src="<?php echo $cart_row['product_img']; ?>" alt="Product Image">
                                    </div>
                                    <div>
                                        <h3><?php echo $cart_row['brand']; ?></h3>
                                        <p><?php echo $cart_row['description']; ?></p>
                                    </div>
                                </td>
                                <td>$<?php echo $cart_row['price']; ?></td>
                                <td class="quantity-control">
                                    <form action="update_cart.php" method="post">
                                        <input type="hidden" name="cart_id" value="<?php echo $cart_row['id']; ?>">
                                        <input type="number" name="quantity" value="<?php echo $cart_row['quantity']; ?>" min="1">
                                        <input type="submit" class="quantity-button" value="Update">
                                    </form>
                                </td>
                                <td>$<?php echo $cart_row['price'] * $cart_row['quantity']; ?></td>
                                <td>
                                    <form action="remove_from_cart.php" method="post">
                                        <input type="hidden" name="cart_id" value="<?php echo $cart_row['id']; ?>">
                                        <input type="submit" class="remove-button" value="Remove">
                                    </form>
                                </td>
                            </tr>
                            <?php
                            // Calculate and accumulate the total sum
                            $total_sum += $cart_row['price'] * $cart_row['quantity'];
                        }
                        ?>
                        <!-- Display total sum row -->
                        <tr>
                            <td colspan="3"></td>
                            <td><strong>Total:</strong></td>
                            <td>$<?php echo $total_sum; ?></td>
                        </tr>
                    </tbody>
                </table>
                <a href="checkout.php" class="checkout-button">Checkout</a>
            </div>
            <?php
        }  else {
            // Cart is empty
            echo "Your cart is empty.";
        }
        // Close connection
        $conn->close();
        ?>
    </main>

    <footer>
    <p>Contact Us : 17871 | Shift@gmail.com</p>
    <p>Follow us : @Shift_Performances</p>
    <p>© 2024 Car Parts Galore. All rights reserved.</p>   
    </footer>
</body>
</html>
