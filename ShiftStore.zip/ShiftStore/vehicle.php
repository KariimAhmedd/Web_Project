<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/vehicle.css">
    <title>Vehicle</title>
</head>
<body>

    <a href="home.php">
        <h1 id="site-name">Shift Store</h1>
    </a>

    <h3 id="under-name">For tuning and modification</h3>

    <nav class="top-menu">
        <ul>
            <li class="dropmenu">
                <a href="vehicle.php">VEHICLE</a>
                <ul class="dropdown-menu vehicle-dropdown">
                    <li><a href="product.php?brand=audi">AUDI</a></li>
                    <li><a href="product.php?brand=bmw">BMW</a></li>
                    <li><a href="product.php?brand=mercedes">MERCSDES</a></li>
                    <li><a href="product.php?brand=vw">VW</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="product.php">PRODUCTS</a>
                <ul class="dropdown-menu product-dropdown">
                <li><a href="product.php?category=rims">Rims</a></li>
                <li><a href="product.php?category=exhaust">Exhaust System</a></li>
                <li><a href="product.php?category=intake">Intake</a></li>
                <li><a href="product.php?category=suspensions">Suspensions</a></li>
                <li><a href="product.php?category=software">Software/Tuning</a></li>
                <li><a href="product.php?category=turbo">Turbo/Superchargers</a></li>

                </ul>
            </li>

            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="support.php">SUPPORT</a></li>
            <li><a href="cart.php" id="cart-button"><i class="fas fa-shopping-cart"></i> CART</a></li>
            <li>
                    <div id="welcome-message">
                    <?php
                    // Start session
                    session_start();

                    // Check if the user is logged in
                    if (isset($_SESSION['user_name'])) {
                        // User is logged in, display the welcome message
                        echo '<li>Welcome, ' . htmlspecialchars($_SESSION['user_name']) . '!</li>';
                        // Add logout link here if needed
                    } else {
                        // User is not logged in, display login link
                        echo '<li><a href="login.html" id="login-button"><i class="fa fa-user"></i> LOGIN</a></li>';
                    }
                    ?>
                    </div>
            </li>
            <li>
            <a href="logout.php" id="login-button"><i class="fa fa-user"></i> LOGOUT</a>
            </li>

        </ul>
    </nav>


    <section class="all">
    <div class="smoky-text">
            <span class="text">Vehicle</span>
        </div>
            <div class="vehicle-list" >
                <?php
                // Database connection code
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "product";

                $conn = new mysqli($servername, $username, $password, $dbname);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // SQL query to fetch vehicles from the database
                $sql = "SELECT * FROM vehicles"; // Update with your table name
                $result = $conn->query($sql);
                ?>

                <main>
                    <section class="vehicle-list">
                    <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<div class="vehicle" data-brand="' . htmlspecialchars($row["brand"]) . '">
                                        <h3 class="brand-name">' . htmlspecialchars($row["brand"]) . '</h3>
                                        <img src="' . htmlspecialchars($row["image_url"]) . '" alt="' . htmlspecialchars($row["type"]) . '">
                                        <h3 class="title">' . htmlspecialchars($row["type"]) . '</h3>
                                        <div class="vehicle-details-popup">
                                            <h4>More about ' . htmlspecialchars($row["type"]) . '</h4>
                                            <p>' . htmlspecialchars($row["details"]) . '</p>
                                        </div>
                                    </div>';
                            }
                        } else {
                            echo "<p>No vehicles found.</p>";
                        }
                        $conn->close();
                        ?>
                    </section>
                </main>

            </div> 
        </div>
    </section>

    <footer>
    <p>Contact Us : 17871 | Shift@gmail.com</p>
    <p>Follow us : @Shift_Performances</p>
    <p>© 2024 Car Parts Galore. All rights reserved.</p>
    </footer>
</body>
</html>
