<?php
require 'vendor/autoload.php';
require 'config.php';
include('C:\xampp\htdocs\ShiftStore\vendor\classes\Swift\SmtpTransport.php'); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $sql = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email exists, create a reset token
        $token = bin2hex(random_bytes(50));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $sql = "UPDATE users SET reset_token=?, reset_token_expiry=? WHERE email=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $token, $expiry, $email);
        $stmt->execute();

        // Mailtrap SMTP settings
        $smtp_host = 'sandbox.smtp.mailtrap.io';
        $smtp_port = 587;
        $smtp_username = '2abc6aa0f3c8b3';
        $smtp_password = 'fd80e692a91943';
        $from_email = 'no-reply@yourdomain.com';
        $from_name = 'Your App Name';

        // Send the reset link to the user's email using Mailtrap SMTP
        $transport = (new Swift_SmtpTransport($smtp_host, $smtp_port))
            ->setUsername($smtp_username)
            ->setPassword($smtp_password);

        $mailer = new Swift_Mailer($transport);

        $message = (new Swift_Message('Password Reset Request'))
            ->setFrom([$from_email => $from_name])
            ->setTo([$email])
            ->setBody("To reset your password, click the following link: http://yourdomain.com/reset_password.php?token=" . $token);

        // Send the email
        $result = $mailer->send($message);

        if ($result) {
            echo "A password reset link has been sent to your email.";
        } else {
            echo "Failed to send email.";
        }
    } else {
        echo "No account found with that email address.";
    }

    $stmt->close();
    $conn->close();
}
?>
