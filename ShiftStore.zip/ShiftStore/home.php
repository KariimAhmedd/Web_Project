<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/home.css">
    <title>Home</title>
</head>

<body>
    <a href="home.php">
        <h1 id="site-name">Shift Store</h1>
    </a>


    <h3 id="under-name">For tunning and modification</h3>

    <nav class="top-menu">
        <ul>
            <li class="dropmenu">
                <a href="vehicle.php" class="vehicle">VEHICLE</a>
                <ul class="dropdown-menu vehicle-dropdown">
                    <li><a href="product.php?brand=audi">AUDI</a></li>
                    <li><a href="product.php?brand=bmw">BMW</a></li>
                    <li><a href="product.php?brand=mercedes">MERCSDES</a></li>
                    <li><a href="product.php?brand=vw">VW</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="product.php">PRODUCTS</a>
                <ul class="dropdown-menu product-dropdown">
                    <li><a href="product.php?category=rims">Rims</a></li>
                    <li><a href="product.php?category=exhaust">Exhaust System</a></li>
                    <li><a href="product.php?category=intake">Intake</a></li>
                    <li><a href="product.php?category=suspensions">Suspensions</a></li>
                    <li><a href="product.php?category=software">Software/Tuning</a></li>
                    <li><a href="product.php?category=turbo">Turbo/Superchargers</a></li>
                </ul>
            </li>

            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="support.php">SUPPORT</a></li>
            <li><a href="cart.php" id="cart-button"><i class="fa fa-shopping-cart"></i> CART</a></li>
            <li>
                    <div id="welcome-message">
                    <?php
                    // Start session
                    session_start();

                    // Check if the user is logged in
                    if (isset($_SESSION['user_name'])) {
                        // User is logged in, display the welcome message
                        echo '<li>Welcome, ' . htmlspecialchars($_SESSION['user_name']) . '!</li>';
                        // Add logout link here if needed
                    } else {
                        // User is not logged in, display login link
                        echo '<li><a href="login.html" id="login-button"><i class="fa fa-user"></i> LOGIN</a></li>';
                    }
                    ?>
                    </div>
            </li>
            <li>
            <a href="logout.php" id="login-button"><i class="fa fa-user"></i> LOGOUT</a>
            </li>
        </ul>
    </nav>
    <div class="top">
        <div class="slideshow">
            <img class="mySlides"
                src="https://i.shgcdn.com/a9fd041e-dff8-4559-bad7-a07957af4eee/-/format/auto/-/preview/3000x3000/-/quality/lighter/"
                style="display: block;">

            <img class="mySlides" src="https://parksidemotors.ca/wp-content/uploads/2020/12/Is-Your-Car-Backfiring.jpg"
                style="display: block;">

            <img class="mySlides" src="https://bigkidsid.files.wordpress.com/2019/08/img_4967.jpg"
                style="display: block;">

            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>

        <div class="bundle">
            <a href="#">
                <img src="https://urotuned.com/unitronic-stage2-mk6-gti.jpg" alt=""></a>
            <h3 class="text">BUNDLE OF THE MONTH - GOLF BUNDLE</h3>

            <a href="#">
                <img src="https://www.tuningcarbonhoods.co.uk/22581-large_default/body-kit-mercedes-w205-amg-2-doors-look-c63.jpg"
                    alt=""></a>
            <h3 class="text">BUNDLE OF THE MONTH - C63 KIT</h3>


        </div>

        <div class="bundle-2">
            <a href="#">
                <img src="https://fmic.eu/media/catalog/product/cache/e49a16b951bdaea102accaa6a07b2883/z/e/zestawtuningowy004.png"
                    alt=""></a>
            <h3 class="text">BUNDLE OF THE MONTH - BMW BUNDLE</h3>

            <a href="#">
                <img src="https://www.getunitronic.com/media/images/blog/c8-rs6-rs7-stg3-software/Blog-4-0TFSI-C8-RS6-Stage3-TTE1020-perf-soft-banner-5b-web.jpg"
                    alt=""></a>
            <h3 class="text">BUNDLE OF THE MONTH - AUDI BUNDLE</h3>


        </div>

    </div>

    <main>
        <section class="featured-products">
            <h2>Featured Products</h2>
            <div class="product-list">
                <div class="product" data-brand="mercedes">
                    <a href="product.php?category=rims">
                        <img src="https://www.ladnefelgi.pl/hpeciai/3d374b4b61b5ae788226d93336242267/eng_pl_4x-rims-20-for-MERCEDES-E-W211-W212-W213-S-W222-HX06F-80943_4.webp"
                            alt="mercedes rims"></a>
                    <h3> RIMS</h3>
                    <p>Biggest Rims for more stable. nice gamd</p>
                </div>

                <div class="product" data-brand="bmw">
                    <a href="product.php?category=exhaust">
                        <img src="https://rm-motors.com/8655-large_default/downpipe-bmw-e81-e87-e82-e88-116d-118d-120d-123d-n47.jpg"
                            alt="bmw down pipe"></a>
                    <h3> Down Pipe </h3>
                    <p>listen esm3333333 esm33333333</p>
                </div>

                <div class="product" data-brand="VW">
                    <a href="product.php?category=intake">
                        <img src="https://cdn11.bigcommerce.com/s-k6ksy074j3/images/stencil/1280x1280/products/135/448/eb668741-ef14-44d9-9ac9-3ac183b53d49__92203.1671549096__41377.1677408241.jpg?c=1"
                            alt="VW air intake "></a>
                    <h3> Air Intake </h3>
                    <p>Improve breathing your engine </p>
                </div>

                <div class="product" data-brand="mercedes">
                    <a href="product.php?category=suspensions">
                        <img src="https://i.ebayimg.com/images/g/YSYAAOSwvXBi4i9w/s-l1200.jpg"
                            alt="suspension for mercedes benz brabus"></a>
                    <h3> suspension</h3>
                    <p>make it dirfting ya basha 3wm we malksh d3wa </p>

                </div>

                <div class="product" data-brand="software">
                    <a href="product.php?category=software">
                        <img src="https://www.eurosports.com.sg/shop/wp-content/uploads/2020/04/Stage-3-Software-Cover-AUDI-Tuning-Remap-Chiptuning-Reflash-upgrade.jpg"
                            alt="ECU software"></a>
                    <h3> Software </h3>
                    <p>second step to 1,000 hp. nice gamd</p>
                </div>

                <div class="product" data-brand="audi">
                    <a href="product.php?category=turbo">
                        <img src="https://cdn10.bigcommerce.com/s-gnopa3kz47/products/2003/images/3084/825614-5005S__62330__44694.1475759439.500.659.jpg?c=2"
                            alt="audi turbo"></a>
                    <h3> BIG TURBO </h3>
                    <p>MAN ITS TURBO !! Stuuustuuuu</p>
                </div>

            </div>
        </section>
    </main>

    <p>Contact Us : 17871 | Shift@gmail.com</p>
    <p>Follow us : @Shift_Performances</p>
    <p>© 2024 Car Parts Galore. All rights reserved.</p>

    <script src="Script/home.js"></script>
</body>

</html>