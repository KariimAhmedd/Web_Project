var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");

    if (n > slides.length) {
        slideIndex = 1;
    }

    if (n < 1) {
        slideIndex = slides.length;
    }

    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slides[slideIndex - 1].style.display = "block";
}

var slideInterval = setInterval(function () {
    plusSlides(1);
}, 3000);

document.querySelector('.slideshow').addEventListener('mouseenter', function () {
    clearInterval(slideInterval);
});

document.querySelector('.slideshow').addEventListener('mouseleave', function () {
    slideInterval = setInterval(function () {
        plusSlides(1);
    }, 3000);
});


document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('login-form').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting

        var formData = new FormData(this);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'login.php', true);
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.onload = function() {
            if (xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                console.log('Username:', response.username);
                console.log('Redirect URL:', response.redirect_url);
                document.getElementById('username-text').textContent = response.username;
                document.getElementById('login-button').style.display = 'none';
                document.getElementById('username').style.display = 'block';
                window.location.href = response.redirect_url;                
            } else {
                console.error('Failed to login');
            }
        };
        xhr.send(formData);
    });
});


