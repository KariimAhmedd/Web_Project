function addToCart(productId, name, price) {
    var quantity = 1; // Default quantity
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '<?php echo $_SERVER['PHP_SELF']; ?>', true); // Send request to same page
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var response = JSON.parse(xhr.responseText);
            if (response.success) {
                updateCart();
            } else {    
                console.error('Failed to add item to cart');
            }
        }
    };
    xhr.send('action=add&product_id=' + productId + '&name=' + name + '&price=' + price + '&quantity=' + quantity);
}

// Function to update cart display
function updateCart() {
    var xhr = new XMLHttpRequest();
// Assuming that cart.php is in the root directory
xhr.open('GET', '/cart.php?cart=1', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById('cart-items').innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}

// Call updateCart() when the page loads
window.onload = function() {
    updateCart();
    document.getElementById('cart-total').innerText = calculateCartTotal();
};