document.querySelectorAll('.faq-question').forEach(item => {
    item.addEventListener('click', () => {
        // Collapse all other answers
        document.querySelectorAll('.faq-answer').forEach(answer => {
            if (answer !== item.nextElementSibling) {
                answer.style.maxHeight = null; // Closes any other open answers
            }
        });

        // Toggle the answer for the clicked question
        const answer = item.nextElementSibling;
        if (answer.style.maxHeight) {
            answer.style.maxHeight = null; // Close this answer if it's already open
        } else {
            answer.style.maxHeight = answer.scrollHeight + "px"; // Open this answer
        }
    });
});