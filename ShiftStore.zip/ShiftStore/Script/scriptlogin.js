const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

function validatePassword() {
    var password = document.getElementById("signupPassword").value;
    var errorSpan = document.getElementById("passwordError");

    var lowerCaseLetters = /[a-z]/g;
    var upperCaseLetters = /[A-Z]/g;
    var numbers = /[0-9]/g;
    var specialCharacters = /[!@#$%^&*(),.?":{}|<>]/g;

    var isValid = true;
    var errorMessages = [];

    if (!password.match(numbers)) {
        isValid = false;
        errorMessages.push("Password must contain at least one number");
    }

    if (!password.match(lowerCaseLetters)) {
        isValid = false;
        errorMessages.push("Password must contain at least one lowercase letter");
    }

    if (!password.match(upperCaseLetters)) {
        isValid = false;
        errorMessages.push("Password must contain at least one uppercase letter");
    }

    if (!password.match(specialCharacters)) {
        isValid = false;
        errorMessages.push("Password must contain at least one special character");
    }

    if (password.length < 8) {
        isValid = false;
        errorMessages.push("Password must be at least 8 characters long");
    }

    if (isValid) {
        errorSpan.innerText = "";
        document.querySelector(".sign-up form").submit();
    } else {
        var errorMessageHTML = "<ul>";
        errorMessages.forEach(function (message) {
            errorMessageHTML += "<li>" + message + "</li>";
        });
        errorMessageHTML += "</ul>";
        errorSpan.innerHTML = errorMessageHTML;
    }
}

var passwordInput = document.getElementById("signupPassword");
var showPasswordCheckbox = document.getElementById("showPassword");

showPasswordCheckbox.addEventListener("change", function () {
    passwordInput.type = this.checked ? "text" : "password";
});

document.getElementById("signInButton").addEventListener("click", function () {
    window.location.href = "index.html";
});
