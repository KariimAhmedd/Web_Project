<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the submitted form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];

    // Example: Calculate total amount from the cart (assuming you have a cart table)
    $total_amount_query = "SELECT SUM(price * quantity) AS total_amount FROM cart";
    $total_amount_result = $conn->query($total_amount_query);
    $total_amount_row = $total_amount_result->fetch_assoc();
    $total_amount = $total_amount_row['total_amount'];

    // Insert order details into the order table
    $insert_order_query = "INSERT INTO `order` (name, address, payment_method, total_amount) 
                           VALUES ('$name', '$address', '$payment_method', $total_amount)";
    if ($conn->query($insert_order_query) === TRUE) {
        // Order inserted successfully
        // Clear the cart (optional)
        $clear_cart_query = "TRUNCATE TABLE cart"; // Remove all rows from the cart table
        $conn->query($clear_cart_query);

        // Close the database connection
        $conn->close();

        // Redirect the user to a thank you page or homepage
        header("Location: thank_you.html");
        exit;
    } else {
        // Error inserting order
        echo "Error: " . $insert_order_query . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
