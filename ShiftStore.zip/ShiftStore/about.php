<!DOCTYPE html>
<html lang="en">
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/about.css">
    <title>About</title>
</head>

<body>
    <header>
        <a href="home.php">
            <h1 id="site-name">Shift Store</h1>
        </a>


        <h3 id="under-name">For tunning and modification</h3>
    </header>


    <nav class="top-menu">
        <ul>
            <li>


            <li class="dropmenu">
                <a href="vehicle.php" class="vehicle">VEHICLE</a>
                <ul class="dropdown-menu vehicle-dropdown">
                    <li><a href="product.php?brand=audi">AUDI</a></li>
                    <li><a href="product.php?brand=bmw">BMW</a></li>
                    <li><a href="product.php?brand=mercedes">MERCSDES</a></li>
                    <li><a href="product.php?brand=vw">VW</a></li>
                </ul>
            </li>

            </li>
            <li class="dropdown">
                <a href="product.php">PRODUCTS</a>
                <ul class="dropdown-menu product-dropdown">
                    <li><a href="product.php?category=rims">Rims</a></li>
                    <li><a href="product.php?category=exhaust">Exhaust System</a></li>
                    <li><a href="product.php?category=intake">Intake</a></li>
                    <li><a href="product.php?category=suspensions">Suspensions</a></li>
                    <li><a href="product.php?category=software">Software/Tuning</a></li>
                    <li><a href="product.php?category=turbo">Turbo/Superchargers</a></li>

                </ul>
            </li>
            <li><a href="support.php">SUPPORT</a></li>
            <li><a href="cart.php" id="cart-button"><i class="fas fa-shopping-cart"></i> CART</a></li>

            <li>
                <div id="welcome-message">
                    <?php
                // Start session
                session_start();

                // Check if the user is logged in
                if (isset($_SESSION['user_name'])) {
                    // User is logged in, display the welcome message
                    echo '<li>Welcome, ' . htmlspecialchars($_SESSION['user_name']) . '!</li>';
                    // Add logout link here if needed
                } else {
                    // User is not logged in, display login link
                    echo '<li><a href="login.html" id="login-button"><i class="fa fa-user"></i> LOGIN</a></li>';
                }
                ?>
                </div>
            </li>
            <li>
                <a href="logout.php" id="login-button"><i class="fa fa-user"></i> LOGOUT</a>
            </li>

        </ul>
    </nav>
    <main>
        <section id="aboutStore" class="about-section">
            <h1>Welcome to Shift Store</h1>
            <p>
                At Shift Store, we specialize in high-quality automotive parts for both performance and aesthetic
                upgrades. Our passion for cars drives us to offer the best products and services to our customers.
                Whether you're looking to enhance your vehicle's performance or its street appeal, Shift Store has
                everything you need.
            </p>
            <p>
                Founded in 2005, we have over 15 years of experience in the automotive industry. Our team is made up of
                car enthusiasts and professional mechanics who understand your needs and are here to guide you with
                their expert advice.
            </p>
        </section>
        <section id="meetTheTeam" class="team-section">
            <h2>Meet Our Team</h2>
            <p>
                Our team at Shift Store is dedicated to providing you with top-notch customer service and the best
                product recommendations. Get to know the people who make everything happen at Shift Store.
            </p>
            <div class="team-gallery">
                <div class="team-member">
                    <img src="" alt="Ahmed Haitham">
                    <div class="member-info">
                        <h3>Ahmed Haitham</h3>
                        <p>Founder and Ceo</p>
                    </div>
                </div>

                <div class="team-member">
                    <img src="" alt="Ahmed Haitham">
                    <div class="member-info">
                        <h3>Omar Donia</h3>
                        <p>CTO</p>
                    </div>
                </div>

                <div class="team-member">
                    <img src="" alt="Ahmed Haitham">
                    <div class="member-info">
                        <h3>Karim Ahmed</h3>
                        <p>CFO</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <p>Contact Us : 17871 | Shift@gmail.com</p>
    <p>Follow us : @Shift_Performances</p>
    <p>© 2024 Car Parts Galore. All rights reserved.</p>

</body>

</html>