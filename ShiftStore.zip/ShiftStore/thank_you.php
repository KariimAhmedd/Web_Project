<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <link rel="stylesheet" href="Styles/thank_you.css">
</head>
<body>
    <h1>Thank You!</h1>
    <p>Your order has been successfully processed.</p>
    <p>We appreciate your business.</p>
    <a href="home.php">Back to Homepage</a>
</body>
</html>
