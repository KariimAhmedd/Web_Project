<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/product.css">
    <title>Products</title>
</head>
<body>
    <header>
        <a href="home.php">
            <h1 id="site-name">Shift Store</h1>
        </a>
        <h3 id="under-name">For tuning and modification</h3>
    </header>

    <nav class="top-menu">
        <ul>
            <li class="dropmenu">
                <a href="vehicle.php" class="vehicle">VEHICLE</a>
                <ul class="dropdown-menu vehicle-dropdown">
                    <li><a href="product.php?brand=audi">AUDI</a></li>
                    <li><a href="product.php?brand=bmw">BMW</a></li>
                    <li><a href="product.php?brand=mercedes">MERCSDES</a></li>
                    <li><a href="product.php?brand=vw">VW</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="product.php">PRODUCTS</a>
                <ul class="dropdown-menu product-dropdown">
                <li><a href="product.php?category=rims">Rims</a></li>
                <li><a href="product.php?category=exhaust">Exhaust System</a></li>
                <li><a href="product.php?category=intake">Intake</a></li>
                <li><a href="product.php?category=suspensions">Suspensions</a></li>
                <li><a href="product.php?category=software">Software/Tuning</a></li>
                <li><a href="product.php?category=turbo">Turbo/Superchargers</a></li>

                </ul>
            </li>
            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="support.php">SUPPORT</a></li>
            <li><a href="cart.php" id="cart-button"><i class="fas fa-shopping-cart"></i> CART</a></li>
            <li>
                    <div id="welcome-message">
                    <?php
                    // Start session
                    session_start();

                    // Check if the user is logged in
                    if (isset($_SESSION['user_name'])) {
                        // User is logged in, display the welcome message
                        echo '<li>Welcome, ' . htmlspecialchars($_SESSION['user_name']) . '!</li>';
                        // Add logout link here if needed
                    } else {
                        // User is not logged in, display login link
                        echo '<li><a href="login.html" id="login-button"><i class="fa fa-user"></i> LOGIN</a></li>';
                    }
                    ?>
                    </div>
            </li>
            <li>
            <a href="logout.php" id="login-button"><i class="fa fa-user"></i> LOGOUT</a>
            </li>
        </ul>
    </nav>

 
    <nav>
        <input type="search" id="searchBar" placeholder="Search for products..." />
        <select id="brandfliter">
            <option value="all">All Brands</option>
            <option value="product.php?brand=audi">AUDI</option>
            <option value="bmw">BMW</option>
            <option value="mercsdes">MERCSDES</option>
            <option value="vw">VW</option>
        </select>
    </nav>

            <?php
        // Database connection code
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "product"; // Update with your database name

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if a category is chosen from the dropdown menu
        $category = isset($_GET['category']) ? $_GET['category'] : '';

        // Check if a brand is chosen from the dropdown menu
        $brand = isset($_GET['brand']) ? $_GET['brand'] : '';

        // Adjust the SQL query based on the chosen category and brand
        if ($category && $brand) {
            $sql = "SELECT * FROM products WHERE category = '$category' AND brand = '$brand'";
        } elseif ($category) {
            $sql = "SELECT * FROM products WHERE category = '$category'";
        } elseif ($brand) {
            $sql = "SELECT * FROM products WHERE brand = '$brand'";
        } else {
            // Default SQL query to fetch all products
            $sql = "SELECT * FROM products";
        }

        $result = $conn->query($sql);
        ?>

        <main>
    <section class="product-container">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                    echo '<div class="product">';
                    echo '<h3>' . htmlspecialchars($row["brand"]) .'</h3>';
                    echo '<img src="' . htmlspecialchars($row["image_url"]) . '" alt="Product Image">';
                    echo '<h3>' . htmlspecialchars($row["name"]) . '</h3>';
                    echo '<p>$' . htmlspecialchars($row["price"]) . '</p>';
                    echo '<div class="product-details-popup">';
                    echo '<h4>' . htmlspecialchars($row["name"]) . '</h4>';
                    echo '<img src="' . htmlspecialchars($row["image_url"]) . '" alt="Product Image">';
                    echo '<p>Price: $' . htmlspecialchars($row["price"]) . '</p>';
                    echo '<p>' . htmlspecialchars($row["description"]) . '</p>';
                    
                    // Form for adding product to cart
                    echo '<form class="add-to-cart-form" action="add_to_cart.php" method="post">';
                    echo '<input type="hidden" name="product_id" value="' . $row['id'] . '">';
                    echo 'Quantity: <input type="number" class="add-to-cart-quantity" name="quantity" value="1" min="1">';
                    echo '<input type="submit" class="add-to-cart-button" value="Add to Cart">';
                    echo '</form>';
                    
                    echo '</div>'; // Close product-details-popup
                    echo '</div>'; // Close product
                // Close product div         
            }
        }else {
            echo "<p>No products found.</p>";
        }
        $conn->close();
        ?>
    </section>
</main>
 

    <footer>
        <p>Contact Us: 17871 | Shift@gmail.com</p>
        <p>Follow us: @Shift_Performances</p>
        <p>© 2024 Car Parts Galore. All rights reserved.</p>
    </footer>

</body>
</html>