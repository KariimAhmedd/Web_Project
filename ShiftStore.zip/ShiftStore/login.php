<?php
require 'config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query to fetch user by email
    $sql = "SELECT id, name, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stored_hash = $row['password'];
        echo "Stored Hash: " . htmlspecialchars($stored_hash) . "<br>";
        echo "Entered Password: " . htmlspecialchars($password) . "<br>";
        if (password_verify($password, $stored_hash)) {
            // Password is correct, start a new session
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['role'] = $row['role'];
            
            // Check the user's role and redirect accordingly
            if ($row['role'] === 'admin') {
                header('Location: admin-insert-product.html');
            } else {
                header('Location: home.php');
            }
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with that email address.";
    }

    // Close statement
    $stmt->close();
}

// Close database connection
$conn->close();
?>
