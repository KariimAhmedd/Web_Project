<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you receive the product_id and quantity from the frontend
$product_id = $_POST['product_id'];
$quantity = $_POST['quantity'];

// Query to fetch product details
$sql = "SELECT * FROM products WHERE id = $product_id";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    // Product found, fetch its details
    $product_row = $result->fetch_assoc();
    
    // Insert product into cart table
    $insert_query = "INSERT INTO cart (product_id, quantity, brand, price, product_img) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param("iisds", $product_id, $quantity, $product_row['brand'], $product_row['price'], $product_row['image_url']);
    
    if ($stmt->execute()) {
        header("Location: cart.php");
        exit;
    } else {
        echo "Error adding product to cart: " . $conn->error;
    }
} else {
    echo "Product not found!";
}

// Close connection
$conn->close();
?>
