<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles/checkout.css">
    <title>Checkout</title>
</head>
<body>
    <header>
        <h1>Checkout</h1>
    </header>

    <main>
        <h2>Order Summary</h2>
        <div class="cart-section">
            <?php
            // Your PHP code to retrieve items from the cart and display them
            // Establish a database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "product";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query to fetch products from cart
            $cart_query = "SELECT * FROM cart";
            $cart_result = $conn->query($cart_query);

            if ($cart_result->num_rows > 0) {
                // Cart is not empty, display cart contents
                echo "<table class='cart-table'>";
                echo "<tr>";
                echo "<th>Product Image</th>";
                echo "<th>Brand</th>";
                echo "<th>Price</th>";
                echo "<th>Quantity</th>";
                echo "</tr>";
                
                $total_sum = 0; // Initialize total sum variable
                
                // Loop through each cart item and display it in a table row
                while ($cart_row = $cart_result->fetch_assoc()) {
                    echo "<tr class='cart-item'>";
                    echo "<td><img src='" . $cart_row['product_img'] . "' alt='Product Image'></td>";
                    echo "<td>" . $cart_row['brand'] . "</td>";
                    echo "<td>$" . $cart_row['price'] . "</td>";
                    echo "<td>" . $cart_row['quantity'] . "</td>";
                    echo "</tr>";
                
                    // Update total sum
                    $total_sum += $cart_row['price'] * $cart_row['quantity'];
                }
                
                // Display total sum row
                echo "<tr>";
                echo "<td colspan='3'><strong>Total:</strong></td>";
                echo "<td>$total_sum</td>";
                echo "</tr>";
                
                echo "</table>";
                
            } else {
                // Cart is empty
                echo "<p>Your cart is empty.</p>";
            }

            // Close connection
            $conn->close();
            ?>
        </div>

        <div class="checkout-form">
            <h2>Shipping & Payment Information</h2>
            <form action="process_order.php" method="post" onsubmit="return handlePaymentMethod()">
                <!-- Input fields for shipping and payment information -->
                <input type="text" name="name" placeholder="Full Name" required>
                <input type="text" name="address" placeholder="Address" required>
                <input type="radio" id="visa" name="payment_method" value="visa" required>
                <label for="visa">Visa</label>
                <input type="radio" id="cash" name="payment_method" value="cash" required>
                <label for="cash">Cash</label>
                <button type="submit">Place Order</button>
            </form>
        </div>
    </main>

    <footer>
        <p>Contact Us : 17871 | Shift@gmail.com</p>
        <p>Follow us : @Shift_Performances</p>
        <p>© 2024 Car Parts Galore. All rights reserved.</p>   
    </footer>

    <script>
        function handlePaymentMethod() {
            var paymentMethod = document.querySelector('input[name="payment_method"]:checked').value;
            if (paymentMethod === 'visa') {
                window.location.href = 'visa.php';
                return false; // Prevent form submission
            }
            return true; // Allow form submission for other payment methods
        }
    </script>
</body>
</html>
