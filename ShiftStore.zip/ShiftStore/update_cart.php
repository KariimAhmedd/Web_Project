<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "product";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if cart_id and quantity are provided in the POST data
if(isset($_POST['cart_id']) && isset($_POST['quantity'])) {
    // Sanitize the input to prevent SQL injection
    $cart_id = $conn->real_escape_string($_POST['cart_id']);
    $quantity = $conn->real_escape_string($_POST['quantity']);

    // Construct the SQL UPDATE query
    $sql = "UPDATE cart SET quantity = '$quantity' WHERE id = '$cart_id'";

    // Execute the UPDATE query
    if ($conn->query($sql) === TRUE) {
        // Quantity updated successfully, redirect back to cart page
        header("Location: cart.php");
        exit;
    } else {
        // Error occurred while updating quantity
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // Redirect to the cart page if cart_id or quantity is not provided
    header("Location: cart.php");
    exit;
}

// Close the database connection
$conn->close();
?>
