
<!DOCTYPE html>
<html lang="en">
    <head>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Styles/support.css">
        <title>About</title>
    </head>
<body>
    <header>
        <a href="home.php">
            <h1 id="site-name">Shift Store</h1>
        </a>
    
    
        <h3 id="under-name">For tunning and modification</h3>
    </header>


    <nav class="top-menu">
        <ul>

            <li>
                
              
                <li class="dropmenu">
                    <a href="vehicle.php" class="vehicle">VEHICLE</a>
                    <ul class="dropdown-menu vehicle-dropdown">
                        <li><a href="product.php?brand=audi">AUDI</a></li>
                        <li><a href="product.php?brand=bmw">BMW</a></li>
                        <li><a href="product.php?brand=mercedes">MERCSDES</a></li>
                        <li><a href="product.php?brand=vw">VW</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="product.php">PRODUCTS</a>
                    <ul class="dropdown-menu product-dropdown">
                    <li><a href="product.php?category=rims">Rims</a></li>
                    <li><a href="product.php?category=exhaust">Exhaust System</a></li>
                    <li><a href="product.php?category=intake">Intake</a></li>
                    <li><a href="product.php?category=suspensions">Suspensions</a></li>
                    <li><a href="product.php?category=software">Software/Tuning</a></li>
                    <li><a href="product.php?category=turbo">Turbo/Superchargers</a></li>
    
                    </ul>
                </li>
                <li><a href="about.php">ABOUT US</a></li>
            <li><a href="cart.php" id="cart-button"><i class="fas fa-shopping-cart"></i> CART</a></li>
            <li>
                <div id="welcome-message">
                <?php
                // Start session
                session_start();

                // Check if the user is logged in
                if (isset($_SESSION['user_name'])) {
                    // User is logged in, display the welcome message
                    echo '<li>Welcome, ' . htmlspecialchars($_SESSION['user_name']) . '!</li>';
                    // Add logout link here if needed
                } else {
                    // User is not logged in, display login link
                    echo '<li><a href="login.html" id="login-button"><i class="fa fa-user"></i> LOGIN</a></li>';
                }
                ?>
                </div>
        </li>
        <li>
        <a href="logout.php" id="login-button"><i class="fa fa-user"></i> LOGOUT</a>
        </li>
        </ul>
    </nav>
    </header>
    <main>
        <section id="supportSection">
            <h1>Customer Support</h1>
            <p>If you need assistance, we're here to help! Check out our FAQs or contact our support team directly.</p>
            
            <div class="support-content">
                <div class="faq">
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq-item">
                        <button class="faq-question">How do I track my order?</button>
                        <div class="faq-answer">
                            <p>You can track your order by logging into your account and visiting the orders section.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button class="faq-question">What are the payment options available?</button>
                        <div class="faq-answer">
                            <p>We accept all major credit cards, PayPal,bank transfers, and COD  is available only inside Egypt.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button class="faq-question">How do I return or exchange an item?</button>
                        <div class="faq-answer">
                            <p>Please contact our support team for a return authorization, and then send the item back to us following the provided instructions.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button class="faq-question">How can I contact customer service?</button>
                        <div class="faq-answer">
                            <p>You can reach our customer service team via email at support@shiftstore.com or by phone at (123) 456-7890.</p>
                        </div>
                    </div>
                </div>
                <div class="contact-info">
                    <h2>Contact Us</h2>
                    <p>Our support team is available 24/7:</p>
                    <p>Phone: (123) 456-7890</p>
                    <p>instagram: shift_store</p>
                </div>
            </div>
        </section>
    </main>
    
    <footer>
        <p>© 2024 Shift Store. All rights reserved.</p>
    </footer>
    <script src="Script/support.js"></script>
</body>
</html>